```
npm install
npm start
```

## Не забудь звезду!
