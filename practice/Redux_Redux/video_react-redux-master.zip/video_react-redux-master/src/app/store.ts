// npm i redux @types/redux
import { combineReducers, createStore } from 'redux';

const reducer = combineReducers({});
const store = createStore(reducer);

export default store;
