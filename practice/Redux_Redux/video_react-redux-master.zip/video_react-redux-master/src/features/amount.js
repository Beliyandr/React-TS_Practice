const ADD = 'amount/ADD';
const TAKE = 'amount/TAKE';
const CLEAR = 'amount/CLEAR';

const amountReducer = (amount = 0, action) => {
  return amount;
};

export default amountReducer;
