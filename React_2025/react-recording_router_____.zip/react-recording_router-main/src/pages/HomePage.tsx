export const HomePage = () => (
  <h1 className="title">Home page</h1>
);
