import { UserPosts } from './components/UserPosts';

export const App = () => (
  <div className="section py-5">
    <UserPosts userId={11} />
  </div>
);
