const ADD = 'goods/ADD';
const TAKE = 'goods/TAKE';
const CLEAR = 'goods/CLEAR';

const goodsReducer = (goods = [], action) => {
  return goods;
};

export default goodsReducer;
